import type React from "react";
import type { AccidentalMode, ButtonKind, FontFamily, NotationMode } from "./types";

/*
  Shared pitch spelling tables.

  Internally, the app stores pitch classes using sharp names:
  C, C#, D, D#, etc.

  Display names are then chosen based on notation settings.
*/

export const FLAT_NAMES: Record<string, string> = {
  C: "C",
  "C#": "Db",
  D: "D",
  "D#": "Eb",
  E: "E",
  F: "F",
  "F#": "Gb",
  G: "G",
  "G#": "Ab",
  A: "A",
  "A#": "Bb",
  B: "B",
};


export const ENHARMONIC_ENGLISH: Record<string, string> = {
  C: "C",
  "C#": "C#/Db",
  D: "D",
  "D#": "D#/Eb",
  E: "E",
  F: "F",
  "F#": "F#/Gb",
  G: "G",
  "G#": "G#/Ab",
  A: "A",
  "A#": "A#/Bb",
  B: "B",
};

export const ENHARMONIC_SOLFEGE: Record<string, string> = {
  C: "Do",
  "C#": "Do#/Reb",
  D: "Re",
  "D#": "Re#/Mib",
  E: "Mi",
  F: "Fa",
  "F#": "Fa#/Solb",
  G: "Sol",
  "G#": "Sol#/Lab",
  A: "La",
  "A#": "La#/Sib",
  B: "Si",
};

export const ENHARMONIC_GERMAN: Record<string, string> = {
  C: "C",
  "C#": "Cis/Des",
  D: "D",
  "D#": "Dis/Es",
  E: "E",
  F: "F",
  "F#": "Fis/Ges",
  G: "G",
  "G#": "Gis/As",
  A: "A",
  "A#": "Ais/B",
  B: "H",
};

export const SOLFEGE_SHARP: Record<string, string> = {
  C: "Do",
  "C#": "Do#",
  D: "Re",
  "D#": "Re#",
  E: "Mi",
  F: "Fa",
  "F#": "Fa#",
  G: "Sol",
  "G#": "Sol#",
  A: "La",
  "A#": "La#",
  B: "Si",
};

export const SOLFEGE_FLAT: Record<string, string> = {
  C: "Do",
  "C#": "Reb",
  D: "Re",
  "D#": "Mib",
  E: "Mi",
  F: "Fa",
  "F#": "Solb",
  G: "Sol",
  "G#": "Lab",
  A: "La",
  "A#": "Sib",
  B: "Si",
};


export const GERMAN_DEFAULT: Record<string, string> = {
  C: "C",
  "C#": "Des",
  D: "D",
  "D#": "Es",
  E: "E",
  F: "F",
  "F#": "Ges",
  G: "G",
  "G#": "As",
  A: "A",
  "A#": "B",
  B: "H",
};

export const GERMAN_SHARP: Record<string, string> = {
  C: "C",
  "C#": "Cis",
  D: "D",
  "D#": "Dis",
  E: "E",
  F: "F",
  "F#": "Fis",
  G: "G",
  "G#": "Gis",
  A: "A",
  "A#": "Ais",
  B: "H",
};

export const GERMAN_FLAT: Record<string, string> = {
  C: "C",
  "C#": "Des",
  D: "D",
  "D#": "Es",
  E: "E",
  F: "F",
  "F#": "Ges",
  G: "G",
  "G#": "As",
  A: "A",
  "A#": "B",
  B: "H",
};

export const INTERVALS_FROM_C: Record<string, string> = {
  C: "1",
  "C#": "b2",
  D: "2",
  "D#": "b3",
  E: "3",
  F: "4",
  "F#": "b5",
  G: "5",
  "G#": "b6",
  A: "6",
  "A#": "b7",
  B: "7",
};

export const NATURAL_NAMES: Record<string, string> = {
  C: "C",
  "C#": "Db",
  D: "D",
  "D#": "Eb",
  E: "E",
  F: "F",
  "F#": "Gb",
  G: "G",
  "G#": "Ab",
  A: "A",
  "A#": "Bb",
  B: "B",
};

export const PITCH_INDEX: Record<string, number> = {
  C: 0,
  "C#": 1,
  D: 2,
  "D#": 3,
  E: 4,
  F: 5,
  "F#": 6,
  G: 7,
  "G#": 8,
  A: 9,
  "A#": 10,
  B: 11,
};

export const INDEX_TO_PITCH = [
  "C",
  "C#",
  "D",
  "D#",
  "E",
  "F",
  "F#",
  "G",
  "G#",
  "A",
  "A#",
  "B",
];

/**
 * Transposes a pitch class by a number of semitones.
 */
export function transpose(pitch: string, semitones: number): string {
  const index = PITCH_INDEX[pitch];
  return INDEX_TO_PITCH[(index + semitones + 120) % 12];
}

/**
 * Converts an internal pitch class into the selected visible notation.
 */
export function formatPitch(
  pitch: string | undefined,
  notation: NotationMode,
  accidental: AccidentalMode,
  defaultDisplayName?: string,
  octave?: number
): string {
  if (!pitch || notation === "blank") return "";

  const octaveSuffix = octave === undefined ? "" : String(octave);

  if (notation === "intervals") return INTERVALS_FROM_C[pitch] ?? pitch;

  if (notation === "solfege") {
    const solfegeName =
      accidental === "enharmonic"
        ? ENHARMONIC_SOLFEGE[pitch] ?? pitch
        : accidental === "sharps"
          ? SOLFEGE_SHARP[pitch] ?? pitch
          : SOLFEGE_FLAT[pitch] ?? pitch;
    return `${solfegeName}${octaveSuffix}`;
  }

  if (notation === "german") {
    const germanName =
      accidental === "enharmonic"
        ? ENHARMONIC_GERMAN[pitch] ?? pitch
        : accidental === "sharps"
          ? GERMAN_SHARP[pitch] ?? pitch
          : accidental === "flats"
            ? GERMAN_FLAT[pitch] ?? pitch
            : GERMAN_DEFAULT[pitch] ?? pitch;
    return `${germanName}${octaveSuffix}`;
  }

  if (accidental === "enharmonic") {
    return `${ENHARMONIC_ENGLISH[pitch] ?? pitch}${octaveSuffix}`;
  }

  if (accidental === "natural") {
    const defaultName = defaultDisplayName ?? NATURAL_NAMES[pitch] ?? pitch;
    return `${defaultName}${octaveSuffix}`;
  }

  if (accidental === "flats") return `${FLAT_NAMES[pitch] ?? pitch}${octaveSuffix}`;
  return `${pitch}${octaveSuffix}`;
}

/**
 * Renders b/# characters as proper music symbols.
 * The symbols are slightly lowered to mimic accordion chart notation.
 * Double sharps are stored internally as ## and displayed with the standard
 * double-sharp sign.
 */
export function renderMusicLabel(label: string) {
  const parts: React.ReactNode[] = [];

  for (let index = 0; index < label.length; index += 1) {
    const char = label[index];
    const nextChar = label[index + 1];

    if (char === "#" && nextChar === "#") {
      parts.push(
        <tspan key={index} className="accidental-symbol double-sharp-symbol" baselineShift="-14%">
          𝄪
        </tspan>
      );
      index += 1;
      continue;
    }

    if (char === "#") {
      parts.push(
        <tspan key={index} className="accidental-symbol" baselineShift="-18%">
          ♯
        </tspan>
      );
      continue;
    }

    if (char === "b") {
      parts.push(
        <tspan key={index} className="accidental-symbol" baselineShift="-18%">
          ♭
        </tspan>
      );
      continue;
    }

    parts.push(<tspan key={index}>{char}</tspan>);
  }

  return parts;
}

/** Returns true when a normalized pitch class contains a sharp accidental. */
export function isAccidentalPitch(pitch: string | undefined): boolean {
  return Boolean(pitch && pitch.includes("#"));
}

/** Returns the compact suffix used when displaying chord names. */
export function chordSuffix(kind: ButtonKind): string {
  if (kind === "chord-major") return "";
  if (kind === "chord-minor") return "m";
  if (kind === "chord-dominant7") return "7";
  if (kind === "chord-diminished7") return "d";
  return "";
}

/** Returns a short row-function label for Stradella chord rows. */
export function rowFunction(kind: ButtonKind): string {
  if (kind === "chord-major") return "M";
  if (kind === "chord-minor") return "m";
  if (kind === "chord-dominant7") return "7";
  if (kind === "chord-diminished7") return "d";
  return "";
}

/** Identifies whether a button kind represents a chord row. */
export function isChordKind(kind: ButtonKind) {
  return kind.startsWith("chord");
}

/**
 * Generates visible chord tones for chord-tone label mode.
 *
 * Modern Stradella dominant seventh and diminished buttons usually omit the fifth:
 * - 7th chord: 1-3-b7
 * - diminished chord: 1-b3-bb7
 */
export function chordTones(
  root: string,
  kind: ButtonKind,
  notation: NotationMode,
  accidental: AccidentalMode
) {
  if (notation === "blank") return "";

  const intervals =
    kind === "chord-major"
      ? [0, 4, 7]
      : kind === "chord-minor"
      ? [0, 3, 7]
      : kind === "chord-dominant7"
      ? [0, 4, 10]
      : kind === "chord-diminished7"
      ? [0, 3, 9]
      : [0];

  return intervals.map((i) => formatPitch(transpose(root, i), notation, accidental)).join("-");
}

/** Converts a named font option into the CSS class used by App.css. */
export function fontClass(font: FontFamily): string {
  return `font-${font}`;
}
